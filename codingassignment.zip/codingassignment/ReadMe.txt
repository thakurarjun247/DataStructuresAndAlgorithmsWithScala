The solution is in Scala language and contains the following three files:
1. Queue.scala : The trait as mentioned in the problem statement.
2. QueueImpl.scala : Implementation of Queue trait.
3. Application.scala : Creates queue and runs some assertion.
